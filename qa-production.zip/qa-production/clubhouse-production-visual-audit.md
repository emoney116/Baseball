# Clubhouse Production Visual Audit

Captured from the authenticated production deployment serving commit `0fa8caacf739cc89282c85a70133e048944b5e70`.

## Production surfaces

| Screenshot group | Viewports | Result | Notes |
| --- | --- | --- | --- |
| Clubhouse Home | 390x844, 430x932 | PASS | Global mobile navigation is present and usable; shared Ask Clubhouse FAB is visible without covering it. |
| Team Home | 390x844, 430x932, 820x1180, 1180x820, 1440x900 | PASS | Team context and launcher are visible; no detached rectangular Ask Clubhouse control. |
| Practice Overview | 390x844, 430x932, 820x1180, 1180x820 | PASS | Practice controls remain readable and the shared launcher does not cover tracking actions. |
| Games / Game Center | 390x844, 430x932, 820x1180, 1180x820, 1440x900 | PASS | Campbell's Game Center surface remains intact. |
| Weight Room | 390x844, 430x932 | PASS | Shared launcher and bottom navigation have separate space. |
| Analytics Games Standard | 390x844, 430x932, 820x1180, 1180x820, 1440x900 | PASS | Dense stat sheet, sticky player column, compact metrics, and no page-level horizontal overflow observed. |
| Analytics Practice Development | 390x844, 430x932 | PASS | Practice-specific metrics render with real tracked data and compact rows. |
| Analytics later columns | 390x844, 430x932 | PASS | Stat region scrolls horizontally while the player column stays visible. |
| Analytics Columns control | 390x844, 430x932 | PASS | Preset/metric dialog opens as a compact sheet/dialog. |
| Ask Clubhouse empty | 390x844, 430x932, 820x1180, 1180x820, 1440x900 | PASS | Full-screen phone presentation hides global bottom navigation; close control and composer are visible. |
| Ask Clubhouse live answers | 390x844, 430x932 | PASS with follow-up | Knowledge, ranking, identity, low-data, development, refusal, and follow-up states rendered in production. |

## Visual findings

- **Blockers:** none found.
- **Major:** none found.
- **Minor:** the first 430px empty-state capture showed stale suggested prompts until a production reload. The refreshed production state showed the current prompt set; verify cache invalidation during the next release smoke test.
- **Follow-up:** long conversation captures stayed near the beginning of the chat while later answers were appended. Verify on physical iPhone Safari that the chat auto-scrolls to a newly completed answer and that long answers remain reachable above the fixed composer.
- **Polish:** live Ask Clubhouse messages are information-dense on 390px; typography remains legible, but the answer hierarchy should be reviewed alongside the physical-device smoke test.

## Live functional evidence

- `What is OPS?` returned a reviewed Baseball Knowledge answer.
- `Who has the highest Practice Contact %?` returned Trevor Snyder at 100% (2-for-2) with Jacob Seamon identified as the qualified 12-swing leader at 88% (21-for-24).
- `What is chase rate?` returned Baseball Knowledge content and did not resolve Chase Kiker.
- `How is Chase hitting?` resolved Chase Kiker and correctly reported no tracked Fall 2026 hitting events for him.
- `Who hits curveballs best?` returned a bounded insufficient-data response.
- `How can Jacob hit sliders better?` returned a zero-sample development diagnosis with tracking guidance and no unsupported mechanical claim.
- `Write my history essay.` returned an out-of-scope refusal.
- `How about fastballs?` used the preceding conversation context and returned a 4-seam fastball comparison with coverage details.

## Deployment and QA notes

- Production deployment: Ready; deployed SHA `0fa8caacf739cc89282c85a70133e048944b5e70`.
- Production browser console: no warning/error entries during the live pass.
- Physical iPhone Safari/PWA smoke testing remains required.
- This file and all PNGs in `qa-production/` are local QA artifacts and must remain untracked.
