# Analytics V2 Final Visual Audit

Date: 2026-09-02
Preview: `https://baseball-git-feature-clu9-39-analytics-v2-emoney116s-projects.vercel.app/`
Data: authenticated Metrolina Varsity Practice data; no mock data or provider calls.

## Result

Acceptance result: PASS with minor/polish observations. No blocker or major visual finding remains after the velocity-rendering and tablet-sheet fixes.

## Viewport Coverage

| Viewport | States captured | Result |
| --- | --- | --- |
| 390x844 | overview, filters, velocity range, In Zone, Pitch Types, Columns | PASS |
| 430x932 | overview, filters | PASS |
| 820x1180 | overview, filters | PASS; sheet fully inside viewport |
| 1180x820 | filters | PASS; sheet fully inside viewport |
| 1440x900 | overview, filters, Pitch Types, Columns, Count, Velocity 80 | PASS |

## Functional Checks

- Velocity minimum `80`: PASS. No TypeError or page crash; the result set changed and the active `80+ mph` state was visible.
- Velocity `85`: PASS. Active value and results updated.
- Blank velocity: PASS through the live stepper interaction; prior velocity state cleared without a crash.
- Custom `80-85`: PASS. Range state rendered and remained bounded.
- Pitch Location: PASS for the live selector. In Zone and Down & Away produced honest no-data states for the current Practice sample; no unrelated team total was shown.
- Count: PASS. A no-match count selection showed no tracked data and no unfiltered TEAM aggregate; partial-coverage copy remained visible.
- Handedness: PASS for the available partial-coverage state; no unsupported result was fabricated.
- Domain/view reset: PASS. Switching Hitting to Pitching and back reset the leading view row to `Overview` and `scrollLeft` was `0`.
- Body overflow: PASS. `document.body.scrollWidth` matched the viewport width at all five target viewports.
- iPad filter sheet: PASS. At 820x1180 the sheet measured within the viewport at approximately x=180, width=460; at 1180x820 it was centered at approximately x=360, width=460.
- Dense table: PASS. The player column remained frozen, stat columns were compact, and the stat region—not the page—was horizontally scrollable.
- Samples: PASS. Real Practice data displayed `1 samples`/`2 samples` caveats for sparse Avg EV values.

## Data States

- Practice Overview: real data, 20 players with 4 players represented and 39 tracked opportunities.
- Practice Pitch Types: real 4-Seam and Other splits; team total remained weighted.
- Practice location/count filters: real no-match states with coverage messaging; no invented values.
- Games and Game State: no fabricated Game rows were used in this pass because the current authenticated selection did not provide qualifying events for those views.

## Findings

### BLOCKER

None.

### MAJOR

None.

### MINOR

1. At 390px, the dense control row is intentionally horizontally scrollable, so the rightmost `Columns` control can appear partially clipped until the row is moved. The page itself does not overflow, and the DOM label remains `Columns: Development`/`Columns: Custom`.
2. Longer player names are abbreviated in the narrow sticky column on phone. The accessibility/underlying row text remains identifiable, but a few visual names use an ellipsis.
3. The Vercel development toolbar control is visible over the right edge of the table in Preview screenshots. This is deployment tooling, not the Clubhouse UI, but it slightly competes with the stat surface.

### POLISH

1. Sparse Avg EV caveats are present and correct, but could receive stronger visual emphasis in a future table polish pass.
2. The 1180x820 screenshot was captured with the page at a lower scroll position, leaving more empty space above the table than the portrait capture. This is capture state, not a layout failure.
3. Filter controls are consistent in the tested states; some long multi-select rows naturally rely on horizontal movement on phone.

## Evidence Files

- `analytics-v2-final-phone-contact-sheet.png`
- `analytics-v2-final-ipad-contact-sheet.png`
- `analytics-v2-final-desktop-contact-sheet.png`
- `analytics-v2-final-filters-contact-sheet.png`

All files in this directory are local-only and ignored by Git.

## Git/Validation Notes

- Actual local fix commits are `04401db` and `c416af2`; the prompt's reference hashes `2c06ba8`, `0fc096b`, and `40249ef` are not present in this repository history.
- Automated validation completed: build passed, tests `164/164`, lint passed with 0 errors and 25 existing image warnings, TypeScript passed, and `git diff --check` passed.
