# CLU9-39 Authenticated Preview Visual Audit

Preview: authenticated Clubhouse Analytics V2 on the feature deployment.

## Coverage

- Phone: 390x844 and 430x932
- iPad: 820x1180 portrait and 1180x820 landscape
- Desktop: 1440x900
- Dark and light theme spot checks
- Real Metrolina data: Practice hitting, Practice pitching, and Games empty-state

## Findings

### Blocker

- Numeric velocity filter: entering `80` in the Min field crashes the deployed page with `TypeError: number 80 is not iterable`. The page recovers after reload. No code fix was made during this audit.

### Major

- iPad portrait filter sheet is positioned partly off-screen (measured x=-52.9px for a 460px dialog at 820px viewport width), clipping the left side of the filter content.
- Empty split views (for example Practice Counts and Practice vs LHP/RHP with no qualifying dimension coverage) show `No matching data` but still render the unfiltered full team total row. This can be read as a result for the selected split.

### Minor

- The horizontal control row retains a non-zero scroll position after navigation, leaving the leading Season control clipped to a partial `n` on phone screenshots.
- The horizontal analytics tab row can retain its scroll position, leaving `Overview` partially clipped after moving to Game State. The active view remains visible.
- On phone, the Columns control label is clipped to `Columns: Developm...` when the wider Development preset is selected.

### Polish

- The player column is readable and sticky, but truncates several full names at phone widths; this is an acceptable density tradeoff but could use a later detail affordance review.
- Practice Avg EV is correctly marked with a very small real sample (2 team samples); the current compact table makes that qualification easy to miss without reading the secondary line.

## Real-data notes

- Practice hitting produced real rows for 4-Seam and Other pitch types.
- Practice hitting filter coverage is explicit: pitch type is populated, velocity is partial, while count, pitcher hand, and location are not sufficiently populated for reliable splits.
- Practice pitching produced real data for Mylo White, including 10 pitches and 80% Strike%.
- Games currently has no tracked game events for this team, so Game State and game box-score captures are honest empty states.
- No Ask Clubhouse request, provider call, web search, database write, or production mutation was made during this visual pass.
